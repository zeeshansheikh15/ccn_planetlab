#!/bin/bash
while :
do 
	traceroute pl1.rcc.uottawa.ca
 	sleep 3600
done
