#!/bin/bash
while :
do
	ping planetlab1.aut.ac.nz -c 20
	sleep 3600
done
