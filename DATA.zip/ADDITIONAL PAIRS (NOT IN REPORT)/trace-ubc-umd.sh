#!/bin/bash
while :
do 
	traceroute salt.planetlab.cs.umd.edu	
	sleep 3600
done
