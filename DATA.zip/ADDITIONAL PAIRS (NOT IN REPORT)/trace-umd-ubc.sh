#!/bin/bash
while :
do 
	traceroute planetlab1.cs.ubc.ca
 	sleep 3600
done
