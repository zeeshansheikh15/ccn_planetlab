#!/bin/bash
while :
do 
	ping planetlab2.dtc.umn.edu -c 20
 	sleep 3600
done
