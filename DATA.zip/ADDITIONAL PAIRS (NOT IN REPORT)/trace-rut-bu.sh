#!/bin/bash
while :
do 
	traceroute planetlab-02.bu.edu
	sleep 3600
done
