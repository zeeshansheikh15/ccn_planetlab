#!/bin/bash
while :
do 
	traceroute planetlab3.cs.uoregon.edu
	sleep 3600
done
