#!/bin/bash
while :
do 
	ping salt.planetlab.cs.umd.edu -c 20
 	sleep 3600
done
