#!/bin/bash
while :
do 
	ping planetlab1.cs.ubc.ca -c 20
 	sleep 3600
done
