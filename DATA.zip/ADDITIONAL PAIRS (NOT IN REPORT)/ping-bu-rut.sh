#!/bin/bash
while :
do
	ping planetlab3.rutgers.edu -c 20 
	sleep 3600
done
