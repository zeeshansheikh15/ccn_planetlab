#!/bin/bash
while :
do 
	traceroute planetlab-4.eecs.cwru.edu	
 	sleep 3600
done
