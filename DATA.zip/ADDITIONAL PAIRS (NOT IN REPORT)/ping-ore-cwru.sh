#!/bin/bash
while :
do 
	ping planetlab-4.eecs.cwru.edu -c 20
 	sleep 3600
done
