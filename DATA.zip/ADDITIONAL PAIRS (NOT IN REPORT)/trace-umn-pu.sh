#!/bin/bash
while :
do 
	traceroute planetlab1.cs.purdue.edu 
	sleep 3600
done
