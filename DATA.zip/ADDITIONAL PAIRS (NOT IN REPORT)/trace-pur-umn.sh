#!/bin/bash
while :
do 
	traceroute planetlab2.dtc.umn.edu
 	sleep 3600
done
