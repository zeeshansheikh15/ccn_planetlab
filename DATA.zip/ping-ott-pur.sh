#!/bin/bash
while :
do 
	ping planetlab1.cs.purdue.edu -c 20
 	sleep 3600
done
