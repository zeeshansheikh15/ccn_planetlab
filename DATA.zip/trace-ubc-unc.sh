#!/bin/bash
while :
do 
	traceroute planetlab2.cs.unc.edu
 	sleep 3600
done
