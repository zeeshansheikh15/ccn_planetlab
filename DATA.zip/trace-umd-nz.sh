#!/bin/bash
while :
do
	traceroute planetlab1.aut.ac.nz
	sleep 3600
done
