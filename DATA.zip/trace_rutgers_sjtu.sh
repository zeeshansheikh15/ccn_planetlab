#!/bin/bash
while :
do
	traceroute planetlab-1.sjtu.edu.cn
	sleep 3600
done
