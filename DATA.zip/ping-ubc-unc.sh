#!/bin/bash
while :
do 
	ping planetlab2.cs.unc.edu -c 20 
	sleep 3600
done
