#!/bin/bash
while :
do
	traceroute planetlab3.rutgers.edu
	sleep 3600
done
