#!/bin/bash
while :
do 
	ping pl1.rcc.uottawa.ca -c 20 
	sleep 3600
done
