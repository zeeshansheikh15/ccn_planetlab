#!/bin/bash
while :
do
	ping planetlab-1.sjtu.edu.cn -c 20 
	sleep 3600
done
